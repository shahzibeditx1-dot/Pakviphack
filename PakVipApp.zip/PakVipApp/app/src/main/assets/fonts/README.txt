Yahan Jameel Noori Nastaleeq ki .ttf file rakhein aur uska naam ye rakhein:
jameel_noori_nastaleeq.ttf
(Bina font ke app chalega, par Urdu normal font mein dikhegi.)
