APK banane ke steps:
1. Android Studio mein File > Open > PakVipApp folder.
2. Gradle sync hone dein (internet chahiye).
3. app/src/main/assets/fonts/ mein jameel_noori_nastaleeq.ttf rakhein.
4. Build > Build Bundle(s)/APK(s) > Build APK(s).
APK yahan milegi: app/build/outputs/apk/debug/app-debug.apk
