Build the APK on GitHub:
1. Upload all files of this project to your GitHub repository.
2. Add the font file to app/src/main/assets/fonts/ (see README there).
3. Open the Actions tab. The "Build APK" workflow runs automatically.
4. When it finishes, download "app-debug" from Artifacts. The APK is inside.

Build locally: open this folder in Android Studio, then Build > Build APK(s).
