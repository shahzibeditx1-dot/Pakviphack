package com.example.pakvip

import android.annotation.SuppressLint
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.LayerDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var webView: WebView
    private lateinit var overlay: LinearLayout
    private val handler = Handler(Looper.getMainLooper())

    private val HOME = "https://pakvip.co/#/"
    private val REGISTER =
        "https://www.pakvip.co/#/register?invitationCode=17561101154"

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = FrameLayout(this)

        webView = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            webViewClient = object : WebViewClient() {
                override fun shouldOverrideUrlLoading(
                    view: WebView, request: WebResourceRequest
                ): Boolean {
                    val url = request.url.toString()
                    // Only allow links inside pakvip.co
                    if (!url.contains("pakvip.co")) return true
                    if (isLoginUrl(url)) {
                        showOverlay(true)
                        return true
                    }
                    return false
                }

                override fun doUpdateVisitedHistory(
                    view: WebView, url: String?, isReload: Boolean
                ) {
                    checkLogin(url)
                }
            }
            loadUrl(REGISTER)
        }
        root.addView(webView, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)

        overlay = buildOverlay()
        overlay.visibility = View.GONE
        root.addView(overlay, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)

        setContentView(root)

        // Light polling to catch SPA hash changes
        handler.post(object : Runnable {
            override fun run() {
                checkLogin(webView.url)
                handler.postDelayed(this, 300)
            }
        })
    }

    private fun isLoginUrl(url: String?) = url?.contains("#/login") == true

    private fun checkLogin(url: String?) {
        showOverlay(isLoginUrl(url))
    }

    private fun showOverlay(show: Boolean) {
        overlay.visibility = if (show) View.VISIBLE else View.GONE
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    // 3D look: dark bottom layer + gradient top layer
    private fun button3d(top: Int, bottom: Int, shadow: Int): LayerDrawable {
        val base = GradientDrawable().apply {
            setColor(shadow); cornerRadius = dp(18).toFloat()
        }
        val face = GradientDrawable(
            GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(top, bottom)
        ).apply {
            cornerRadius = dp(18).toFloat()
            setStroke(dp(2), Color.parseColor("#55FFFFFF"))
        }
        return LayerDrawable(arrayOf(base, face)).apply {
            setLayerInset(1, 0, 0, 0, dp(8)) // Face on top, 8dp shadow at the bottom
        }
    }

    private fun buildOverlay(): LinearLayout {
        val urdu = try {
            // app/src/main/assets/fonts/jameel_noori_nastaleeq.ttf
            Typeface.createFromAsset(assets, "fonts/jameel_noori_nastaleeq.ttf")
        } catch (e: Exception) {
            Typeface.DEFAULT_BOLD
        }

        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setBackgroundColor(Color.parseColor("#F2101820"))
            setPadding(dp(24), dp(24), dp(24), dp(24))
            isClickable = true // Block touches reaching the login screen behind

            // Message 3D box (display only)
            val msg = TextView(context).apply {
                text = "سب سے پہلے رجسٹر کریں\nلاگ ان نہیں کر سکتے"
                typeface = urdu
                textSize = 26f
                setTextColor(Color.WHITE)
                gravity = Gravity.CENTER
                layoutDirection = View.LAYOUT_DIRECTION_RTL
                setLineSpacing(0f, 1.5f)
                background = button3d(
                    Color.parseColor("#FF5A5F"),
                    Color.parseColor("#C62828"),
                    Color.parseColor("#7F1010")
                )
                setPadding(dp(24), dp(28), dp(24), dp(40))
                setShadowLayer(6f, 0f, 3f, Color.parseColor("#99000000"))
            }
            addView(msg, LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { bottomMargin = dp(28) })

            // Register button
            val reg = Button(context).apply {
                text = "رجسٹر کریں"
                typeface = urdu
                textSize = 24f
                setTextColor(Color.WHITE)
                isAllCaps = false
                background = button3d(
                    Color.parseColor("#43D17A"),
                    Color.parseColor("#1E9E52"),
                    Color.parseColor("#0F5C2E")
                )
                setPadding(dp(16), dp(16), dp(16), dp(24))
                setOnClickListener {
                    showOverlay(false)
                    webView.loadUrl(REGISTER)
                }
            }
            addView(reg, LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(80)
            ))
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (webView.canGoBack()) webView.goBack() else super.onBackPressed()
    }
}
