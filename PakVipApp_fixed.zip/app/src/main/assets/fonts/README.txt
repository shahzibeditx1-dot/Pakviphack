Put the Jameel Noori Nastaleeq .ttf file in this folder and name it exactly:
jameel_noori_nastaleeq.ttf
Without it the app still works, but Urdu text uses the default font.
